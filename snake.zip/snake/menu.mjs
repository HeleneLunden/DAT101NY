"use strict";

/* Use this file to create the menu for the snake game. */

